"""Shared plumbing for the one-shot ingestion pipelines (PLAN.md section 5.1).

Three rules govern everything in this package:

* **RULE 3 — seeds over scraping.** Pipelines run *offline*, write
  ``seeds/*.json``, and those snapshots are committed. The runtime never calls
  ``pmajay.dosje.gov.in`` or ``kaushalverse.ncvet.gov.in``.
* **Politeness.** ``INGEST_QPS=1`` -> one request per second, identified UA,
  raw responses cached under ``seeds/raw/`` (TECH_STACK section 2.3).
* **No fabrication.** When a source blocks, times out, changes schema, errors or
  is unreachable, the pipeline emits a *structurally identical* synthetic
  snapshot with ``synthetic: true`` on every record and a ``provenance`` block
  saying exactly what failed. It never dresses invented rows as official data.
"""

from __future__ import annotations

import datetime as dt
import hashlib
import json
import logging
import pathlib
import threading
import time
from dataclasses import asdict, dataclass, field
from typing import Any

import httpx

LOG_FORMAT = "%(asctime)s %(levelname)-5s [%(name)s] %(message)s"
logging.basicConfig(level=logging.INFO, format=LOG_FORMAT)

REPO = pathlib.Path(__file__).resolve().parents[1]
SEEDS = REPO / "seeds"
RAW = SEEDS / "raw"
DOCS = REPO / "docs"

SEEDS.mkdir(parents=True, exist_ok=True)
RAW.mkdir(parents=True, exist_ok=True)


# --------------------------------------------------------------------------
# Politeness
# --------------------------------------------------------------------------


class RateLimiter:
    """Process-wide minimum interval between outbound requests."""

    def __init__(self, qps: float) -> None:
        self._min_interval = 1.0 / qps if qps > 0 else 0.0
        self._lock = threading.Lock()
        self._last = 0.0

    def wait(self) -> None:
        with self._lock:
            now = time.monotonic()
            sleep_for = self._min_interval - (now - self._last)
            if sleep_for > 0:
                time.sleep(sleep_for)
            self._last = time.monotonic()


# --------------------------------------------------------------------------
# Provenance
# --------------------------------------------------------------------------


@dataclass
class Provenance:
    """Honest record of where a seed file's rows came from.

    ``mode`` is one of ``live`` (fetched from the real source), ``synthetic``
    (the source was unavailable; rows are generated and flagged) or ``mixed``.
    """

    pipeline: str
    source_url: str
    mode: str
    fetched_at: str = field(default_factory=lambda: dt.datetime.now(dt.UTC).isoformat())
    rows: int = 0
    synthetic: bool = False
    http_status: int | None = None
    failure_reason: str | None = None
    fallback_note: str | None = None
    notes: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class PipelineResult:
    name: str
    seed_path: pathlib.Path
    provenance: Provenance

    @property
    def rows(self) -> int:
        return self.provenance.rows

    @property
    def synthetic(self) -> bool:
        return self.provenance.synthetic


# --------------------------------------------------------------------------
# HTTP
# --------------------------------------------------------------------------


def build_client(ua: str, timeout: float = 30.0, verify: bool = True) -> httpx.Client:
    """HTTP client for ingestion.

    ``verify=False`` exists only for government hosts that serve an incomplete
    TLS chain, and only when an operator opts in explicitly per pipeline. It is
    never used by the runtime service.
    """
    return httpx.Client(
        timeout=timeout,
        follow_redirects=True,
        verify=verify,
        headers={
            "User-Agent": ua,
            "Accept": "application/json, text/html;q=0.9, */*;q=0.8",
            "Accept-Language": "en-IN,en;q=0.9,hi;q=0.8",
        },
    )


def cache_raw(name: str, content: bytes) -> pathlib.Path:
    """Cache a raw response body under seeds/raw/ (TECH_STACK section 2.3)."""
    path = RAW / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(content)
    return path


# --------------------------------------------------------------------------
# Seed IO — deterministic and idempotent
# --------------------------------------------------------------------------


def write_seed(path: pathlib.Path, records: list[dict], provenance: Provenance) -> pathlib.Path:
    """Write a seed snapshot.

    The envelope is always ``{provenance, records}``; records are written in a
    stable order with sorted keys so re-running a pipeline against an unchanged
    source produces a byte-identical file (Gate 2 demands idempotency).
    """
    provenance.rows = len(records)
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {"provenance": provenance.to_dict(), "records": records}
    text = json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True)
    path.write_text(text + "\n", encoding="utf-8")
    return path


def read_seed(path: pathlib.Path) -> tuple[dict, list[dict]]:
    if not path.exists():
        return {}, []
    payload = json.loads(path.read_text(encoding="utf-8"))
    if isinstance(payload, list):  # tolerate a bare list
        return {}, payload
    return payload.get("provenance", {}), payload.get("records", [])


def seed_fingerprint(path: pathlib.Path) -> str:
    """Hash of the *records only* — provenance timestamps must not affect it,
    otherwise idempotency could never be proven."""
    _, records = read_seed(path)
    blob = json.dumps(records, ensure_ascii=False, sort_keys=True).encode("utf-8")
    return hashlib.sha256(blob).hexdigest()


def stable_rng(seed_text: str):
    """Deterministic RNG so synthetic snapshots are reproducible byte-for-byte."""
    import random

    return random.Random(int(hashlib.sha256(seed_text.encode("utf-8")).hexdigest()[:16], 16))


# --------------------------------------------------------------------------
# Reporting
# --------------------------------------------------------------------------


def record_run(result: PipelineResult) -> None:
    """Append an ``ingest_runs`` row when a database is reachable.

    Pipelines must still work with no database (a judge may run `make ingest`
    before `make up` finishes), so a failure here is logged and swallowed.
    """
    log = logging.getLogger(result.name)
    try:
        import sys

        sys.path.insert(0, str(REPO / "services"))
        from core.db import session_scope
        from core.models.tables import IngestRun

        with session_scope() as db:
            db.add(
                IngestRun(
                    pipeline=result.name,
                    mode=result.provenance.mode,
                    source_url=result.provenance.source_url,
                    rows=result.rows,
                    ok=not result.synthetic,
                    note=result.provenance.failure_reason or result.provenance.fallback_note,
                )
            )
    except Exception as exc:
        log.info("ingest_runs not recorded (%s) — seed file is still authoritative", type(exc).__name__)


def summarise(results: list[PipelineResult]) -> str:
    lines = ["| # | pipeline | mode | rows | seed file |", "|---|---|---|---|---|"]
    for idx, res in enumerate(results, start=1):
        mode = "SYNTHETIC" if res.synthetic else res.provenance.mode.upper()
        rel = res.seed_path.relative_to(REPO).as_posix()
        lines.append(f"| {idx:02d} | {res.name} | {mode} | {res.rows:,} | `{rel}` |")
    return "\n".join(lines)


def env(name: str, default: str) -> str:
    import os

    return os.environ.get(name, default)


def env_float(name: str, default: float) -> float:
    try:
        return float(env(name, str(default)))
    except ValueError:
        return default


def as_int(value: Any) -> int | None:
    try:
        if value in (None, "", "null", "NA", "N/A"):
            return None
        return int(float(value))
    except (TypeError, ValueError):
        return None


def as_float(value: Any) -> float | None:
    try:
        if value in (None, "", "null", "NA", "N/A"):
            return None
        return float(value)
    except (TypeError, ValueError):
        return None


def clean(value: Any) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    return text or None
