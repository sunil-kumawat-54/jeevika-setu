# AI-Driven Voice Assistant — PM-AJAY GIA × NSQF Skilling (SIH dossier)

**Project AVSAR** — *Aspiration-to-Vocational Skilling Assistant & Recommender*
Voice-first livelihood mapping + NSQF-aligned skilling recommendations for SC communities under the Grant-in-Aid component of PM-AJAY (Ministry of Social Justice & Empowerment).

## Files

| File | Read this when… |
|---|---|
| **`research.md`** | You need the evidence. Every claim adversarially verified against primary sources; refuted claims listed in Appendix A so you never quote them. Feeds slides S4/S6 directly. |
| **`PLAN.md`** | You're deciding what/when. Personas, MVP scope, recommendation algorithm, dialogue design, phase-by-phase build, hour-by-hour finale plan, risk register, judging map. |
| **`ARCHITECTURE.md`** | You're building. Monorepo layout, component diagram, data model, API contract, voice/LLM/RAG subsystems, deployment. |
| **`TECH_STACK.md`** | You need exact libs/endpoints/env vars. Pinned dependencies, Bhashini/Sarvam/Kaushalverse contracts, performance budgets. |
| **`FABLE_PROMPT.md`** | You want it built. Paste the prompt into Fable 5; it reads all four files and executes gate-by-gate. |

## The 30-second version

The PM-AJAY GIA guidelines *already legally require* mapping beneficiary aspiration → local job market → NSQF QPs before any skilling money moves (Ch. 3 §7.A.a.iv). That loop runs on paper today while ₹736 cr of ₹2,140 cr went unspent (FY2024-25 actual). AVSAR is the missing front door: speak your aspiration in Hindi/Marathi/Telugu → get a grounded course recommendation with assistance facts → officers get a live livelihood map and AAP-ready exports. Built on verified-live government data surfaces (PM-AJAY catalogue ~1,893 QP-coded courses; NCVET Kaushalverse JSON API) with Bhashini PoC keys for speech and a mock mode that survives dead venue wifi.

## Quickstart — full offline demo, zero API keys

**Prereqs: Docker Desktop and GNU Make. Nothing else.** No Python, Node,
Postgres or Redis on the host; no API key of any kind; no internet after the
images are built. Everything below was run end to end on a clean Windows 11
machine with Docker 28 and GNU Make 4.4.

```bash
git clone <repo> && cd AVSAR
cp .env.example .env     # mock-first defaults are already set: no keys needed
make up                  # builds + starts db, redis, core, web; waits for healthy
make seed                # migrations + committed seeds + demo users + vector index
```

`make up` prints `ALL HEALTHY` when the four containers pass their healthchecks
(first build takes a few minutes; it downloads the embedding model once).

Open **http://localhost:3000** and press **बात शुरू करें / Start conversation**. The whole beneficiary
journey runs offline on `VOICE_PROVIDER=mock` + `LLM_PROVIDER=mock`: language →
spoken consent → five profile slots → spoken aspiration → grounded NSQF
recommendations → summary. Provider egress happens only if you put real keys in
`.env` and run `make mock-off`.

**Officer console:** http://localhost:3000/dashboard — seeded logins
`officer@demo`, `viewer@demo`, `admin@demo`, password from
`DEMO_*_PASSWORD` in `.env` (default `avsar-demo-2026`). Officers get the
district dashboard, the gap panel and CSV/XLSX export; admin adds the audited
crosswalk console.

Useful afterwards: `make ps` (container status), `make logs SVC=core`,
`make down` (stop, keep data), `make clean` (stop and delete the volume).

### Checks — each must exit 0

| Command | What it actually proves |
|---|---|
| `make lint` | ruff over `services pipelines scripts` |
| `make test` | the backend suite against a live Postgres |
| `make grounding` | RULE 2: across 50 randomised sessions, every numeral in the verbalized recommendation exists in the tool JSON, and no course name or QP code was invented |
| `make drill` | kill-a-service: network off (incl. a real `--network none` container), database stopped, provider key revoked — all three degrade gracefully and recover |
| `make latency` | drives real journeys and reports per-stage p50/p95 against the ARCHITECTURE §3 budget |
| `make purge` | retention policy dry-run (`DAYS=30 APPLY=--apply` to delete) |

> `make test` runs against the same database the demo uses and leaves the demo
> data intact. If a dashboard ever looks empty, `make seed` is idempotent — run
> it again.

### Without Docker

The stack is plain FastAPI + Next.js if you would rather run it on the host —
you need Python 3.12, Node 20, Postgres 16 with `pgvector`, and Redis:

```bash
pip install -r services/core/requirements.txt -r services/core/requirements-ml.txt
export PYTHONPATH=services
alembic -c services/core/alembic.ini upgrade head
python scripts/load_demo.py
python -m uvicorn core.main:app --port 8000       # core API
cd apps/web && npm ci && npm run dev              # web on :3000
```

### Honesty about the data

The demo runs on committed `seeds/*.json`, never by scraping a government site
at request time (RULE 3). Some of it is **synthetic**, because the PM-AJAY
portal was serving a maintenance page throughout the build. Synthetic records
carry `synthetic=true` from ingestion through the database, the dashboard badge,
the CSV/XLSX export and the compliance sheet — they are never presented as real
government data. What is real (785 LGD districts, 1,170 NCVET qualifications,
the 43-page GIA guidelines) and what is not is itemised in
[docs/ingest-report.md](docs/ingest-report.md).

Ops procedures (retention purge cron, rate-limit tuning, troubleshooting) live in [docs/runbook.md](docs/runbook.md); architecture in [ARCHITECTURE.md](ARCHITECTURE.md), build order + gate evidence in [PLAN.md](PLAN.md).

## Presentation artifacts

- [docs/slides-outline.md](docs/slides-outline.md) — SIH 6-slide template mapping with verified figures (§7.A.a.iv compliance quote · ₹736.28 cr vs ₹2,140 cr BE · WER table · <₹2/conversation math)
- [scripts/demo_video_shotlist.md](scripts/demo_video_shotlist.md) — 3-minute backup video, shot by shot, plus a 30-second cut; recorded offline
- [docs/decisions.md](docs/decisions.md) — every dossier-silent call recorded with its why
- Deck PDF + recorded video are exported from these two files at submission time.
